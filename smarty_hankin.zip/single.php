<?php get_header(); ?>
<?php get_template_part( 'layouts/single/single' );?>
<?php get_footer(); ?>
