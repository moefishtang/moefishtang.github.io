<?php get_template_part( 'layouts/header/head' );?>
<?php get_template_part( 'layouts/header/nav' );?>
<?php get_template_part( 'layouts/header/top' );?>


