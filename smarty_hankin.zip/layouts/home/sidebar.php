<div class="theiaStickySidebar animated fadeIn" style="padding-top: 0px; padding-bottom: 1px; position: relative; transform: none;">
    <?php if(is_dynamic_sidebar()) dynamic_sidebar('home_sidebar');?>
</div>

  